package com.example.poc;

import org.springframework.stereotype.Component;

@Component
public class LoggerEvent {
	private String region;
	private String environment;
	private String lob;
	private String applicationId;
	private String componentName;
	
	public LoggerEvent() {
		super();
	}
	
	public LoggerEvent(String region, String environment, String lob, String applicationId, String componentName) {
		super();
		this.region = region;
		this.environment = environment;
		this.lob = lob;
		this.applicationId = applicationId;
		this.componentName = componentName;
	}

	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getEnvironment() {
		return environment;
	}
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	public String getComponentName() {
		return componentName;
	}
	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}
}
