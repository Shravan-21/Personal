package com.example.poc;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import static net.logstash.logback.argument.StructuredArguments.v;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class LoggingJsonPocApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoggingJsonPocApplication.class, args);
		Logger log = LoggerFactory.getLogger(LoggingJsonPocApplication.class);
		LoggerEvent logevent = new LoggerEvent("NA","DEV", "Line Of Business", "1234", "component name");
		try
		{
			log.info("Hello from main class", v("region",logevent.getRegion()),v("environment",logevent.getEnvironment()),v("lob",logevent.getLob()),v("applicationId",logevent.getApplicationId()),v("componentName",logevent.getComponentName()));

			throw new NullPointerException("Oh no!");
		}
		catch (Exception e)
		{
			log.error("Could not continue.", e);
		}
	}
}


